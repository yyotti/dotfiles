# vimdoc-ja

Vimの付属ドキュメントを日本語に翻訳するためのプロジェクト

間違いを見つけたらメーリングリストかissueトラッカーでお知らせください。

- Gitリポジトリ https://github.com/vim-jp/vimdoc-ja
- HTML版 http://vim-jp.org/vimdoc-ja/
- issueトラッカー https://github.com/vim-jp/vimdoc-ja/issues
- メーリングリスト http://groups.google.com/group/vimdoc-ja
- Wiki https://github.com/vim-jp/vimdoc-ja/wiki
